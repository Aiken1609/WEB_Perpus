from flask import Flask, g, request, jsonify, send_from_directory, redirect, url_for, render_template, make_response 
from werkzeug.utils import secure_filename
from functools import wraps
import os
import jwt
import datetime
from sqlalchemy import func
from werkzeug.security import check_password_hash, generate_password_hash
from models import db, Buku, User, Review
from AI_buku import rekomendasi_buku

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['SECRET_KEY'] = 'bismillahhirrahmanirrahim_a'
JWT_SECRET = app.config['SECRET_KEY']

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
db.init_app(app)

# Middleware untuk validasi token
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.cookies.get('token')
        print("Token dari cookie:", token)  # debug print
        if not token:
            auth_header = request.headers.get('Authorization')
            if auth_header and auth_header.startswith('Bearer '):
                token = auth_header.split(' ')[1]

        if not token:
            if 'application/json' in request.headers.get('Accept', ''):
                return jsonify({'message': 'Token tidak ditemukan'}), 401
            else:
                return redirect(url_for('login'))

        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            g.current_user = data
        except jwt.ExpiredSignatureError:
            if 'application/json' in request.headers.get('Accept', ''):
                return jsonify({'message': 'Token kadaluarsa'}), 401
            else:
                return redirect(url_for('login'))
        except jwt.InvalidTokenError:
            if 'application/json' in request.headers.get('Accept', ''):
                return jsonify({'message': 'Token tidak valid'}), 401
            else:
                return redirect(url_for('login'))

        return f(*args, **kwargs)
    return decorated

def get_current_user_info():
    user_data = g.current_user
    id_user = user_data['id_user']
    user = User.query.filter_by(id_user=id_user).first()
    if not user:
        return jsonify({'message': 'User tidak ditemukan'}), 404
    return jsonify({
        'id_user': user.id_user,
        'username': user.username,
        'role': user.role,
        'foto': user.foto
    })

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        user_data = g.current_user
        id_user = user_data.get('id_user')
        user = User.query.filter_by(id_user=id_user).first()
        if not user or user.role != 'admin':
            if 'application/json' in request.headers.get('Accept', ''):
                return jsonify({'message': 'Anda bukan admin'}), 403
            else:
                return redirect(url_for('login', message='anda bukan admin'))
        return f(*args, **kwargs)
    return decorated

@app.route('/check_token', methods=['GET'])
@token_required
def check_token():
    token = request.cookies.get('token')
    if not token:
        auth_header = request.headers.get('Authorization')
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header.split(' ')[1]
    return jsonify({'token': token})

@app.before_request
def create_tables():
    db.create_all()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/buku')
@token_required
def buku():
    return render_template('buku.html')

@app.route('/dashboard')
@token_required
@admin_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/dbBuku')
@token_required
@admin_required
def dbBuku():
    return render_template('dbbuku.html')

@app.route('/dbUser')
@token_required
@admin_required
def dbUser():
    return render_template('dbuser.html')

@app.route('/dbReview')
@token_required
@admin_required
def dbReview():
    return render_template('dbreview.html')

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/tambah')
@token_required
@admin_required
def tambah():
    return render_template('add_book.html')

@app.route('/edit_book/<int:id_buku>', methods=['GET'])
@token_required
@admin_required
def edit_book(id_buku):
    book = Buku.query.get_or_404(id_buku)
    return render_template('edit_book.html', book=book)

@app.route('/login', methods=['GET'])
def login():
    return render_template('login.html')

def get_personal_reviews(id_user):
    reviews = db.session.query(
        Review.id_review,
        Review.rating.label('rating_review'),
        Review.created_at,
        Buku.id_buku,
        Buku.judul,
        Buku.foto.label('foto_buku'),
        Buku.penerbit,
        Buku.bahasa,
        Buku.kategori,
        Buku.genre,
        Buku.rating.label('rating_buku'),
        User.id_user,
        User.username,
        User.foto.label('foto_user'),
        User.role
    ).join(Buku, Review.id_buku == Buku.id_buku)\
     .join(User, Review.id_user == User.id_user)\
     .filter(Review.id_user == id_user).all()

    review_list = []
    user_info = None

    for r in reviews:
        if user_info is None:
            user_info = {
                'id_user': r.id_user,
                'username': r.username,
                'foto': r.foto_user,
                'role': r.role
            }
        review_list.append({
            'id_review': r.id_review,
            'rating': r.rating_review,
            'created_at': r.created_at,
            'buku': {
                'id_buku': r.id_buku,
                'judul': r.judul,
                'foto': r.foto_buku,
                'penerbit': r.penerbit,
                'bahasa': r.bahasa,
                'kategori': r.kategori,
                'genre': r.genre,
                'rating': r.rating_buku
            }
        })

    return {
        'user': user_info,
        'reviews': review_list
    }

@app.route("/api/rekomendasi", methods=["POST"])
@token_required
def rekomendasi():
    try:
        # Ambil data buku dari request POST
        input_data = request.json.get("data", [])
        
        if not input_data:
            return jsonify({"error": "Data buku kosong"}), 400

        hasil = rekomendasi_buku(input_data, total_rekomendasi=6)
        return jsonify(hasil), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/reviews_personal', methods=['GET'])
@token_required
def api_personal_reviews():
    id_user = g.current_user['id_user']
    data = get_personal_reviews(id_user)
    return jsonify(data)

@app.route('/profile')
@token_required
def profile():
    user_data = g.current_user
    id_user = user_data['id_user']
    user = User.query.get(id_user)

    data = get_personal_reviews(id_user)
    reviewed_books = data['reviews']
    user_review_info = data['user']  

    return render_template(
        'profile.html',
        user=user,
        reviewed_books=reviewed_books,
        user_review_info=user_review_info
    )

@app.route('/api/reviews_full', methods=['GET'])
@token_required
def get_reviews_full():
    reviews = db.session.query(
        Review.id_review,
        Review.rating,
        Review.created_at,
        Buku.id_buku,
        Buku.judul,
        Buku.foto.label('foto_buku'),
        Buku.penerbit,
        Buku.bahasa,
        Buku.kategori,
        Buku.genre,
        User.id_user,
        User.username,
        User.foto.label('foto_user'),
        User.role
    ).join(Buku, Review.id_buku == Buku.id_buku)\
        .join(User, Review.id_user == User.id_user).all()

    result = []
    for r in reviews:
        result.append({
            'id_review': r.id_review,
            'rating': r.rating,
            'created_at': r.created_at,
            'buku': {
                'id_buku': r.id_buku,
                'judul': r.judul,
                'foto': r.foto_buku,
                'penerbit': r.penerbit,
                'bahasa': r.bahasa,
                'kategori': r.kategori,
                'genre': r.genre
            },
            'user': {
                'id_user': r.id_user,
                'username': r.username,
                'foto': r.foto_user,
                'role': r.role
            }
        })
    return jsonify(result)


@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json()
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'message': 'Username dan password wajib diisi!'}), 400

    user = User.query.filter_by(username=data['username']).first()
    if not user:
        return jsonify({'message': 'Akun belum terdaftar!'}), 404

    if not check_password_hash(user.password, data['password']):
        return jsonify({'message': 'Username atau password salah!'}), 401

    token = jwt.encode({
        'id_user': user.id_user,
        'username': user.username,
        'role': user.role,
        'exp': datetime.datetime.now(datetime.UTC) + datetime.timedelta(hours=2)
    }, app.config['SECRET_KEY'], algorithm='HS256')

    response = make_response(jsonify({
        'message': 'Login berhasil',
        'user': {
            'id_user': user.id_user,
            'username': user.username,
            'role': user.role,
            'foto': user.foto
        }
    }))
    response.set_cookie('token', token, httponly=True, samesite='Lax')
    return response

@app.route('/daftar', methods=['GET', 'POST'])
def daftar():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Cek apakah username sudah digunakan
        if User.query.filter_by(username=username).first():
            # Beri alert menggunakan JavaScript di template
            return render_template('daftar.html', error="Username sudah digunakan!")

        hashed_password = generate_password_hash(password)
        foto = request.files.get('foto')
        filename = secure_filename(foto.filename) if foto and foto.filename else 'default_profile.jpg'
        if foto and foto.filename:
            foto.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

        new_user = User(
            username=username,
            password=hashed_password,
            role='user',
            foto=filename
        )

        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('daftar.html')

@app.route('/rating', methods=['POST'])
@token_required
def submit_rating():
    user_data = g.current_user
    id_user = user_data['id_user']
    data = request.form
    id_buku = data.get('buku_id')
    rating = int(data.get('rating'))

    existing_review = Review.query.filter_by(id_buku=id_buku, id_user=id_user).first()
    if existing_review:
        existing_review.rating = rating
    else:
        new_review = Review(id_buku=id_buku, id_user=id_user, rating=rating)
        db.session.add(new_review)

    db.session.commit()

    reviews = Review.query.filter_by(id_buku=id_buku).all()
    avg_rating = sum([r.rating for r in reviews]) / len(reviews) if reviews else 0
    buku = Buku.query.get(id_buku)
    buku.rating = round(avg_rating, 2)
    db.session.commit()

    return jsonify({"message": "Rating disimpan!", "average_rating": buku.rating, "jumlah_user": len(reviews)})

@app.route('/api/book/<int:id_buku>', methods=['GET'])
@token_required
def get_book_detail(id_buku):
    book = Buku.query.get(id_buku)
    if book:
        return jsonify({
            'id_buku': book.id_buku,
            'judul': book.judul,
            'penerbit': book.penerbit,
            'bahasa': book.bahasa,
            'kategori': book.kategori,
            'genre': book.genre,
            'deskripsi': book.deskripsi,
            'foto': book.foto,
            'rating': book.rating
        })
    else:
        return jsonify({'error': 'Buku tidak ditemukan'}), 404

@app.route('/api/search_review', methods=['GET'])
@token_required
def search_review():
    query = request.args.get('q', '')
    username = request.args.get('username', '')

    q_review = db.session.query(
        Review.id_review,
        Review.rating,
        Review.created_at,
        Buku.judul,
        Buku.foto.label('foto_buku'),
        User.username,
        User.foto.label('foto_user')
    ).join(Buku, Review.id_buku == Buku.id_buku)\
        .join(User, Review.id_user == User.id_user)

    if query:
        q_review = q_review.filter(Buku.judul.ilike(f"%{query}%"))
    if username:
        q_review = q_review.filter(User.username.ilike(f"%{username}%"))

    results = []
    for r in q_review.all():
        results.append({
            'review': {
                'id_review': r.id_review,
                'rating': r.rating,
                'created_at': r.created_at
            },
            'buku': {
                'judul': r.judul,
                'foto': r.foto_buku
            },
            'user': {
                'username': r.username,
                'foto': r.foto_user
            }
        })
    return jsonify(results)

@app.route('/api/search', methods=['GET'])
@token_required
def search_books():
    query = request.args.get('q', '')
    genre = request.args.get('genre', '')
    kategori = request.args.get('kategori', '')
    penerbit = request.args.get('penerbit', '')

    filters = []
    if query:
        filters.append(Buku.judul.ilike(f"%{query}%"))
    if genre:
        filters.append(Buku.genre.ilike(f"%{genre}%"))
    if kategori:
        filters.append(Buku.kategori.ilike(f"%{kategori}%"))
    if penerbit:
        filters.append(Buku.penerbit.ilike(f"%{penerbit}%"))

    if filters:
        books = Buku.query.filter(*filters).all()
    else:
        books = Buku.query.all()

    result = [{
        'id_buku': b.id_buku,
        'judul': b.judul,
        'penerbit': b.penerbit,
        'bahasa': b.bahasa,
        'kategori': b.kategori,
        'genre': b.genre,
        'deskripsi': b.deskripsi,
        'foto': b.foto,
        'rating': b.rating
    } for b in books]

    return jsonify(result)

@app.route('/api/search_user', methods=['GET'])
@token_required
def search_users():
    query = request.args.get('q', '')
    role = request.args.get('role', '')

    filters = []
    if query:
        filters.append(User.username.ilike(f"%{query}%"))
    if role:
        filters.append(User.role.ilike(f"%{role}%"))

    if filters:
        users = User.query.filter(*filters).all()
    else:
        users = User.query.all()

    result = [{
        'id_user': u.id_user,
        'username': u.username,
        'role': u.role,
        'foto': u.foto
    } for u in users]

    return jsonify(result)

@app.route('/detail/<int:id_buku>', methods=['GET'])
@token_required
def detail_buku(id_buku):
    # Ambil data buku menggunakan fungsi get_book_detail
    response = get_book_detail(id_buku)
    if response.status_code == 404:
        return render_template('404.html'), 404

    # response bisa berupa tuple (json, status_code) atau Response object
    if isinstance(response, tuple):
        book_data = response[0].get_json()
    else:
        book_data = response.get_json()
    return render_template('detail.html', buku=book_data)

@app.route('/add_book', methods=['POST'])
def add_book():
    data = request.get_json()
    buku = Buku(
        judul=data['judul'],
        foto=data.get('foto', ''),
        penerbit=data.get('penerbit', ''),
        bahasa=data.get('bahasa', ''),
        kategori=data.get('kategori', ''),
        genre=data.get('genre', ''),
        deskripsi=data.get('deskripsi', ''),
        rating=data.get('rating', 0)
    )
    db.session.add(buku)
    db.session.commit()
    return jsonify({"message": "Buku berhasil ditambahkan!"}), 201

@app.route('/add_books', methods=['POST'])
def add_books():
    data = request.get_json()
    
    # Check if data is a list (bulk insert) or single dictionary
    if isinstance(data, list):
        books = []
        for book_data in data:
            buku = Buku(
                judul=book_data['judul'],
                foto=book_data.get('foto', ''),
                penerbit=book_data.get('penerbit', ''),
                bahasa=book_data.get('bahasa', ''),
                kategori=book_data.get('kategori', ''),
                genre=book_data.get('genre', ''),
                deskripsi=book_data.get('deskripsi', ''),
                rating=book_data.get('rating', 0)
            )
            books.append(buku)
        
        db.session.bulk_save_objects(books)
        db.session.commit()
        return jsonify({"message": f"{len(books)} buku berhasil ditambahkan!"}), 201
    else:
        # Handle single book addition
        buku = Buku(
            judul=data['judul'],
            foto=data.get('foto', ''),
            penerbit=data.get('penerbit', ''),
            bahasa=data.get('bahasa', ''),
            kategori=data.get('kategori', ''),
            genre=data.get('genre', ''),
            deskripsi=data.get('deskripsi', ''),
            rating=data.get('rating', 0)
        )
        db.session.add(buku)
        db.session.commit()
        return jsonify({"message": "Buku berhasil ditambahkan!"}), 201

@app.route('/update/<int:id_buku>', methods=['PUT'])
@token_required
@admin_required
def update_book(id_buku):
    data = request.get_json()
    book = Buku.query.get_or_404(id_buku)
    book.judul = data.get('judul', book.judul)
    foto_baru = data.get('foto')
    if not foto_baru:
        # Ambil data buku dari database untuk mendapatkan foto lama
        buku_lama = Buku.query.get(id_buku)
        book.foto = buku_lama.foto
    else:
        book.foto = foto_baru
    book.penerbit = data.get('penerbit', book.penerbit)
    book.bahasa = data.get('bahasa', book.bahasa)
    book.kategori = data.get('kategori', book.kategori)
    book.genre = data.get('genre', book.genre)
    book.deskripsi = data.get('deskripsi', book.deskripsi)
    db.session.commit()
    return jsonify({"message": "Buku berhasil diupdate!"})

@app.route('/edit_profile', methods=['PUT'])
@token_required
def edit_profile():
    user_data = g.current_user
    user = User.query.get(user_data['id_user'])
    username = request.form.get('username')
    password = request.form.get('password')
    foto = request.files.get('foto')

    # Cek apakah username sudah digunakan oleh user lain
    if username and username != user.username:
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            return jsonify({'error': 'Username sudah digunakan!'}), 400
        user.username = username

    if password:
        user.password = generate_password_hash(password)
    if foto and foto.filename:
        filename = secure_filename(foto.filename)
        foto.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        user.foto = filename

    db.session.commit()
    return jsonify({'message': 'Profil berhasil diperbarui'})

@app.route('/api/reviews', methods=['GET'])
def get_reviews():
    reviews = Review.query.all()
    result = []
    for r in reviews:
        result.append({
            'id_review': r.id_review,
            'id_buku': r.id_buku,
            'id_user': r.id_user,
            'rating': r.rating,
            'created_at': r.created_at
        })
    return jsonify(result)

@app.route('/api/books', methods=['GET'])
def get_books():
    books = Buku.query.all()
    return jsonify([{ 
        'id_buku': b.id_buku,
        'judul': b.judul,
        'foto': b.foto,
        'penerbit': b.penerbit,
        'bahasa': b.bahasa,
        'kategori': b.kategori,
        'genre': b.genre,
        'deskripsi': b.deskripsi,
        'rating': b.rating
    } for b in books])

@app.route('/api/users', methods=['GET'])
def get_users():
    users = User.query.all()
    return jsonify([{
        'id_user': u.id_user,
        'username': u.username,
        'role': u.role,
        'foto': u.foto
    } for u in users])

@app.route('/api/user/<int:id_user>', methods=['GET'])
def get_user_by_id(id_user):
    user = User.query.get(id_user)
    if user:
        return jsonify({
            'id_user': user.id_user,
            'username': user.username,
            'role': user.role,
            'foto': user.foto
        })
    else:
        return jsonify({'message': 'User tidak ditemukan'}), 404

@app.route('/delete_book/<int:id_buku>', methods=['DELETE'])
@token_required
@admin_required
def delete_book(id_buku):
    book = Buku.query.get_or_404(id_buku)
    db.session.delete(book)
    db.session.commit()
    return jsonify({"message": "Buku berhasil dihapus!"})

@app.route('/delete_user', methods=['DELETE'])
@token_required
def delete_user():
    user_data = g.current_user
    id_user = user_data['id_user']
    user = User.query.filter_by(id_user=id_user).first()
    if not user:
        return jsonify({'message': 'User tidak ditemukan'}), 404

    # Ambil semua review milik user ini sebelum dihapus
    user_reviews = Review.query.filter_by(id_user=id_user).all()
    buku_ids = list(set([review.id_buku for review in user_reviews]))

    # Hapus semua review milik user ini
    Review.query.filter_by(id_user=id_user).delete()

    # Hapus user
    db.session.delete(user)
    db.session.commit()

    # Kalkulasi ulang rating untuk setiap buku yang direview user ini
    for id_buku in buku_ids:
        reviews = Review.query.filter_by(id_buku=id_buku).all()
        avg_rating = sum([r.rating for r in reviews]) / len(reviews) if reviews else 0
        buku = Buku.query.get(id_buku)
        if buku:
            buku.rating = round(avg_rating, 2)
    db.session.commit()

    resp = make_response(jsonify({'message': 'Akun dan review berhasil dihapus'}))
    resp.delete_cookie('token')
    return resp

@app.route('/delete_review/<int:id_buku>', methods=['DELETE'])
@token_required
def delete_review(id_buku):
    user_data = g.current_user
    id_user = user_data['id_user']
    
    review = Review.query.filter_by(id_buku=id_buku, id_user=id_user).first()
    if not review:
        return jsonify({'message': 'Review tidak ditemukan'}), 404

    db.session.delete(review)
    
    # Update rating buku
    reviews = Review.query.filter_by(id_buku=id_buku).all()
    avg_rating = sum([r.rating for r in reviews]) / len(reviews) if reviews else 0
    buku = Buku.query.get(id_buku)
    if buku:
        buku.rating = round(avg_rating, 2)
        
    db.session.commit()
    return jsonify({'message': 'Review berhasil dihapus'})

@app.route('/thisuser', methods=['GET'])
@token_required
def current_user():
    return get_current_user_info()

@app.route('/logout')
@token_required
def logout():
    resp = make_response(redirect(url_for('login')))
    resp.delete_cookie('token')
    return resp

if __name__ == '__main__':
    app.run(debug=True)

